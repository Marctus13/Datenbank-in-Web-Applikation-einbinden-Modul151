<?php  
	class Category {

		public function insert($active, $name) {
			global $database;
			$database->beginTransaction();
			$query="INSERT INTO category(active, name) VALUES(?, ?)";

			$insert->bindParam(2, $active, PDO::PARAM_INT);
			$insert->bindParam(4, $name, PDO::PARAM_STR);
			
			$insert->execute();
			$database->commit();

			return $database;
		}

		public function update($category_id, $active, $name) {
			global $database;
			$database->beginTransaction();
			$query="UPDATE category SET active=?, name=? valid_from<=CURRENT_TIMESTAMP WHERE category_id=" . $category_id;

			$update= $database->prepare($query);
			
			$update->bindParam(2, $active, PDO::PARAM_INT);
			$update->bindParam(4, $name, PDO::PARAM_STR);
		
			$insert->execute();
			$database->commit();

			return $database;
		}

		public function select($category_id) {
			global $database;
			$database->beginTransaction();
			$query="SELECT * FROM category WHERE category_id=" . $category_id . " AND valid_from<=CURRENT_TIMESTAMP AND valid_to>CURRENT_TIMESTAMP";
			$select= $database->prepare($query);
			$select->execute();
			$fetchall=$select->setFetchMode(PDO::FETCH_ASSOC);
			foreach($select as $key=> $id) {
				$output[]=$id;
			}
			$database->commit();
			return $output;
		}
		
		public function selectAll() {
			global $database;
			$database->beginTransaction();
			$query="SELECT * FROM category WHERE valid_from<=CURRENT_TIMESTAMP AND valid_to>CURRENT_TIMESTAMP";
			$select= $database->prepare($query);
			$select->execute();
			$fetchall=$select->setFetchMode(PDO::FETCH_ASSOC);
			foreach($select->fetchAll() as $key=> $id) {
				$output[]=$id;
			}
			$database->commit();
			return $output;
		}

		public function delete($category_id) {
			global $database;
			$database->beginTransaction();
			$query("DELETE FROM category WHERE category_id=" . $category_id);
			$delete= $database->prepare($query);
			$delete->execute();
			$database->commit();
			return $database;
		}
	
	}

?>