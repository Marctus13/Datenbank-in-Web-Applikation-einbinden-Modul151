<?php  
	class Product {

		public function insert($sku, $active, $id_category, $name, $image, $description, $price, $stock) {
			global $database;
			$query="INSERT INTO product(sku, active, id_category, name, image, description, price, stock) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";

			$insert= $database->prepare($query);
			
			$insert->bindParam(1, $sku, PDO::PARAM_STR);
			$insert->bindParam(2, $active, PDO::PARAM_INT);
			$insert->bindParam(3, $id_category, PDO::PARAM_INT);
			$insert->bindParam(4, $name, PDO::PARAM_STR);
			$insert->bindParam(5, $image, PDO::PARAM_STR);
			$insert->bindParam(6, $description, PDO::PARAM_STR);
			$insert->bindParam(7, $price, PDO::PARAM_STR);
			$insert->bindParam(8, $stock, PDO::PARAM_INT);
		
			$insert->execute();

			return $database;
		}

		public function update($product_Id, $sku, $active, $id_category, $name, $image, $description, $price, $stock) {
			global $database;
			$query="UPDATE product SET active=?, id_category=?, name=?, description=?, price=?, stock=?, valid_from=CURRENT_TIMESTAMP WHERE product_id=" . $productId;
			
			$update= $database->prepare($query);
			
			$update->bindParam(2, $sku, PDO::PARAM_INT);
			$update->bindParam(2, $active, PDO::PARAM_INT);
			$update->bindParam(3, $id_category, PDO::PARAM_INT);
			$update->bindParam(4, $name, PDO::PARAM_STR);
			$update->bindParam(5, $image, PDO::PARAM_STR);
			$update->bindParam(6, $description, PDO::PARAM_STR);
			$update->bindParam(7, $price, PDO::PARAM_STR);
			$update->bindParam(8, $stock, PDO::PARAM_INT);
		
			$insert->execute();

			return $database;
		}

		public function select($sku) {
			global $database;
			$query="SELECT * FROM product WHERE sku=" . $sku . " AND valid_from<=CURRENT_TIMESTAMP AND valid_to>CURRENT_TIMESTAMP";
			$select= $database->prepare($query);
			$select->execute();
			$fetchall=$select->setFetchMode(PDO::FETCH_ASSOC);
			foreach($select as $key=> $id) {
				$output[]=$id;
			}
			return $output;
		}
		
		public function selectAll() {
			global $database;
			$query="SELECT * FROM product WHERE valid_from<=CURRENT_TIMESTAMP AND valid_to>CURRENT_TIMESTAMP";
			$select= $database->prepare($query);
			$select->execute();
			$fetchall=$select->setFetchMode(PDO::FETCH_ASSOC);
			foreach($select->fetchAll() as $key=> $id) {
				$output[]=$id;
			}
			return $output;
		}

		public function delete($sku) {
			global $database;
			$query("DELETE FROM product WHERE sku=" . $sku);
			$delete= $database->prepare($query);
			$delete->execute();
			return $database;
		}
	}

?>