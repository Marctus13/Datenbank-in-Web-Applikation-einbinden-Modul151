<?php 
	
	require_once "model/Database.php";
	require_once "model/Table.php";

	$name="";
	$password="";

	try {
		$table= new Table();
		$select= $table->select("users");
		$name= $select["name"];
		$password= $select["password"];
	
		
	}	catch (Exception $e) {
		
		http_response_code(500);
		die();
	}

	http_response_code(201);

?>