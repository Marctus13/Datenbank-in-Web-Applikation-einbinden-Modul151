<?php  
	class Table{

		public $tableName;

		public function insert($name, $age) {
			global $database;
		}

		public function update($personId, $name, $age) {
			global $database;
		}

		public function select($name = null) {
			global $database;
			$query="SELECT * FROM " . $name;

			$userdata= $database->prepare($query);
			$userdata->execute();

			$fetchall=$userdata->setFetchMode(PDO::FETCH_ASSOC);
			foreach ($userdata as $user) {
				$authenticate= $user;
			}
			return $authenticate;

		}

		public function delete($personId) {
			global $database;
			$database->query("DELETE FROM " . $this->tableName . " WHERE " . $this->tableName ."_id = " .$personId);
		}
	
	}

?>