<?php 
	require_once "model/Table.php";
	$hostname = "localhost";
	$username = "root";
	$password = "";
	$dbname = "onlineshop";

	try {
		$database = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $password);
	}
	catch (Exception $exception) {
		http_response_code(500);
		echo "Cannot connect to database. This is the error: " . $exception->getMessage();
		die();
	}

?>