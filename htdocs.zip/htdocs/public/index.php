<?php 
	ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);

	use Psr\Http\Message\ResponseInterface as Response;
	use Psr\Http\Message\ServerRequestInterface as Request;
	
	use Slim\Factory\AppFactory;

	use ReallySimpleJWT\Token;

	require __DIR__ . "/../vendor/autoload.php";
	require "model/Category.php";
	require "model/Product.php";
	require "model/Database.php";

	header("Content-Type: application/json");

	$app = AppFactory::create();

	/**
     * @OA\Info(title="Shop API", version="1")
 	*/


	//TEST
	$app->get("/", function (Request $request, Response $response, $args) { 
		$response->getBody()->write("Hello, world Hallo !"); 
		return $response; 
	});


	
	/**
     * @OA\Post(
     *     path="/API/V1/Authenticate",
     *     summary="Used to obtain an access token",
     *     tags={"General"},
     *     requestBody=@OA\RequestBody(
     *         request="/API/V1/Authenticate",
     *         required=true,
     *         description="A JASON object containing the credentials.",
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(property="username", type="string", example="Peter"),
     *                 @OA\Property(property="password", type="string", example="123Abc")
     *             )
     *         )
     *     ),
     *     @OA\Response(response="200", description="Authentication went successfully and a token was stored in the cookies."))
     * )
	*/
	$app->post("/API/V1/Authenticate", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";

		$expiration= time() + 3600;
		$host="localhost";

		$requestBody = file_get_contents("php://input");
		$requestData = json_decode($requestBody, true);

		if (empty($requestData)) {
			http_response_code(400);
			die();
		}


		if ($requestData["name"] == $name && $requestData["password"] == $password) {
			$token= Token::create($name, $password, $expiration, $host);
			setcookie("token", $token, $expiration);
		}
		http_response_code(201);

		return $response;
	});


	
	/**
     * @OA\Post(
     *     path="/API/V1/Product/{sku}",
     *     summary="Create a product",
     *     tags={"Product"},
     *     requestBody=@OA\RequestBody(
     *         request="/API/V1/Product/{sku}",
     *         required=true,
     *         description="All details of the new product to be created must be provided",
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(property="sku", type="integer", example="1353"),
     *                 @OA\Property(property="active", type="integer", example="1"),
     *                 @OA\Property(property="id_category", type="integer", example="2"),	 
     *                 @OA\Property(property="name", type="string", example="Bett"),
     *                 @OA\Property(property="image", type="string", example="Bett.jpg"),				
     *                 @OA\Property(property="description", type="string", example="Bett aus Holz"),
     *                 @OA\Property(property="price", type="string", example="754.95"),
     *                 @OA\Property(property="stock", type="integer", example="1353")
     *             )
     *         )
     *     ),
     *     @OA\Response(response="200", description="Product was created successfully"))
     * )
	*/
	$app->post("/API/V1/Product/{sku}", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}

		$requestBody = file_get_contents("php://input");
		$requestData = json_decode($requestBody, true);

		try {
			$product= new Product();
			$insert=$product->insert(	$requestData["sku"],
										$requestData["active"],
										$requestData["id_category"],
										$requestData["name"],
										$requestData["image"],
										$requestData["description"],
										$requestData["price"],
										$requestData["stock"]
									);

		} catch(Exception $e){
			http_response_code(500);
			die();
		}


		echo json_encode(array(
		"message" => "Product is created: " . $args["sku"]
		));
		http_response_code(201);
		return $response;
	});



	/**
     * @OA\Get(
     *     path="/API/V1/Product/{sku}",
     *     summary="Show a specific product",
     *     tags={"Product"},
     *     @OA\Parameter(
     *         name="sku",
     *         in="path",
     *         required=true,
     *         description="Search by article number",
     *         @OA\Schema(
     *             type="string",
     *             example="Beispiel"
     *         )
     *     ),
     *     @OA\Response(response="200", description="Specific product was found successfully"))
 	*/
	$app->get("/API/V1/Product/{sku}", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}
		
		try {
			$product= new Product();
			$select= $product->select($args["sku"]);
			echo json_encode(
				$select
			);

		} catch(Exception $e) {
			http_response_code(500);
			die();
		}


		http_response_code (201);
		return $response;
	});



	/**
     * @OA\Put(
     *     path="/API/V1/Product/{product_id}",
     *     summary="Update a product",
     *     tags={"Product"},
     *     @OA\Parameter(
     *         name="product_id",
     *         in="path",
     *         required=true,
     *         description="Authenicate users can update a product",
     *         @OA\Schema(
     *             type="string",
     *             example="Beispiel"
     *         )
     *     ),
     *     requestBody=@OA\RequestBody(
     *         request="/API/V1/Product/{product_id}",
     *         required=true,
     *         description="All details of the product to be updated must be specified",
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(property="sku", type="integer", example="1234"),
     *                 @OA\Property(property="active", type="integer", example="1"),
     *                 @OA\Property(property="id_category", type="integer", example="2"),	 
     *                 @OA\Property(property="name", type="string", example="Bett"),
     *                 @OA\Property(property="image", type="string", example="Bett.jpg"),				
     *                 @OA\Property(property="description", type="string", example="Bett aus Holz"),
     *                 @OA\Property(property="price", type="string", example="754.95"),
     *                 @OA\Property(property="stock", type="integer", example="1353")
     *             )
     *         )
     *     ),
     *     @OA\Response(response="200", description="Specific product was successfully updated"))
     * )
	*/
	$app->put("/API/V1/Product/{product_id}", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}

		$requestBody = file_get_contents("php://input");
		$requestData = json_decode($requestBody, true);

		try {
			$product= new Product();
			$update=$product->update(	$args["product_id"],
										$requestData["sku"],
										$requestData["active"],
										$requestData["id_category"],
										$requestData["name"],
										$requestData["image"],
										$requestData["description"],
										$requestData["price"],
										$requestData["stock"]
									);

		} catch(Exception $e){
			http_response_code(500);
			die();
		}


		echo json_encode(array(
		"message" => "product has been updated: " . $args["product_id"]
		));
		http_response_code(201);
		return $response;
	});



	/**
     * @OA\Delete(
     *     path="/API/V1/Product/{sku}",
     *     summary="Product is deleted",
     *     tags={"Product"},
     *     @OA\Parameter(
     *         name="sku",
     *         in="path",
     *         required=true,
     *         description="Specific product will be deleted",
     *         @OA\Schema(
     *             type="string",
     *             example="Beispiel"
     *         )
     *     ),
     *     @OA\Response(response="200", description="Specific product was successfully deleted"))
     * )
	*/
	$app->delete("/API/V1/Product/{sku}", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}
		
		try {
			$product= new Product();
			$delete= $product->delete($args["sku"]);
			echo json_encode(
				$delete
			);

		} catch(Exception $e) {
			http_response_code(500);
			die();
		}
		echo json_encode(array(
		"message" => "product has been deleted: " . $args["sku"]
		));
		http_response_code (201);
		return $response;

	});
	


	/**
     * @OA\Get(
     *     path="/API/V1/Products",
     *     summary="Show all products)",
     *     tags={"Product"},
     *     @OA\Parameter(
     *         name="",
     *         in="path",
     *         required=true,
     *         description="View all products",
     *         @OA\Schema(
     *             type="string",
     *             example="Beispiel"
     *         )
     *     ),
     *     @OA\Response(response="200", description="All products were successfully displayed"))
 	*/	
	$app->get("/API/V1/Products", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}
		
		try {
			$product= new Product();
			$select= $product->selectALL();
			echo json_encode(
				$select
			);

		} catch(Exception $e) {
			http_response_code(500);
			die();
		}


		http_response_code (201);
		return $response;
	});



	/**
     * @OA\Post(
     *     path="/API/V1/Category/{category_id}",
     *     summary="Create a Category",
     *     tags={"Category"},
     *     requestBody=@OA\RequestBody(
     *         request="/API/V1/Category/{category_id}",
     *         required=true,
     *         description="All details of the new category to be created must be provided",
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(property="active", type="integer", example="1"),
     *                 @OA\Property(property="name", type="string", example="Autos")
     *             )
     *         )
     *     ),
     *     @OA\Response(response="200", description="Category was created successfully"))
     * )
	*/
	$app->post("/API/V1/Category/{category_id}", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}

		$requestBody = file_get_contents("php://input");
		$requestData = json_decode($requestBody, true);

		try {
			$category= new Category();
			$insert=$category->insert(	$requestData["active"],
										$requestData["name"]		
									);

		} catch(Exception $e){
			http_response_code(500);
			die();
		}


		echo json_encode(array(
		"message" => "Category is created: " . $args["category_id"]
		));
		http_response_code(201);
		return $response;
	});



	/**
     * @OA\Get(
     *     path="/API/V1/Category/{category_id}",
     *     summary="Show a specific category",
     *     tags={"Category"},
     *     @OA\Parameter(
     *         name="category_id",
     *         in="path",
     *         required=true,
     *         description="Search by category_id",
     *         @OA\Schema(
     *             type="string",
     *             example="1"
     *         )
     *     ),
     *     @OA\Response(response="200", description="Specific category was found successfully"))
 	*/
	$app->get("/API/V1/Category/{category_id}", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}
		
		try {
			$category= new Category();
			$select= $category->select($args["category_id"]);
			echo json_encode(
				$select
			);

		} catch(Exception $e) {
			http_response_code(500);
			die();
		}


		http_response_code (201);
		return $response;
	});



	$app->put("/API/V1/Category/{category_id}", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}

		$requestBody = file_get_contents("php://input");
		$requestData = json_decode($requestBody, true);

		try {
			$category= new Category();
			$update= $category->update(	$args["category_id"],
										$requestData["active"],
										$requestData["name"]
									);

		} catch(Exception $e){
			http_response_code(500);
			die();
		}


		echo json_encode(array(
		"message" => "Category has been updated: " . $args["category_id"]
		));
		http_response_code(201);
		return $response;
	});



	/**
     * @OA\Delete(
     *     path="/API/V1/Category/{category_id}",
     *     summary="Category is deleted",
     *     tags={"Category"},
     *     @OA\Parameter(
     *         name="category_id",
     *         in="path",
     *         required=true,
     *         description="Specific category will be deleted",
     *         @OA\Schema(
     *             type="string",
     *             example="3"
     *         )
     *     ),
     *     @OA\Response(response="200", description="Specific category was successfully deleted"))
     * )
	*/
	$app->delete("/API/V1/Category/{category_id}", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}
		
		try {
			$category= new Category();
			$delete= $category->delete($args["category_id"]);
			echo json_encode(
				$delete
			);

		} catch(Exception $e) {
			http_response_code(500);
			die();
		}
		echo json_encode(array(
		"message" => "Category has been deleted: " . $args["category_id"]
		));
		http_response_code (201);
		return $response;

	});
	


	/**
     * @OA\Get(
     *     path="/API/V1/Categorys",
     *     summary="Show all categorys",
     *     tags={"Category"},
     *     @OA\Parameter(
     *         name="",
     *         in="path",
     *         required=true,
     *         description="View all categorys",
     *         @OA\Schema(
     *             type="string",
     *             example=""
     *         )
     *     ),
     *     @OA\Response(response="200", description="All categorys were successfully displayed"))
	*/
	$app->get("/API/V1/Categorys", function (Request $request, Response $response, $args) {
		require "model/Authenticate.php";
		if (!isset($_COOKIE["token"]) || !Token::validate($_COOKIE['token'], $password)) {
			http_response_code(401);
			die();
		}
		
		try {
			$category= new Category();
			$select= $category->selectALL();
			echo json_encode(
				$select
			);

		} catch(Exception $e) {
			http_response_code(500);
			die();
		}


		http_response_code (201);
		return $response;
	});

$app->run();
	
?>